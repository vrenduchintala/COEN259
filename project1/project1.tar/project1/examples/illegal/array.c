int a[10], b[];
