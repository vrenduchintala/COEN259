int f(void)
{
    int x, y;

    {
	int z;
    }
}
