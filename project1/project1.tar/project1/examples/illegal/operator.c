int f(void)
{
    int x, y, z;

    x = y | z;
}
