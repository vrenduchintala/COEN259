int f(void)
{
    int a, b;

    if (a < b)
	a = a - b;
    else;
}
