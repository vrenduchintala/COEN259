int x, y, z;

int f() {
}
